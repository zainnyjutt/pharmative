<?php
    session_start();
    $message="";
	
$email=$_POST['email'];
$password=$_POST['password'];

$servername="localhost";
$username="root";
$password="";
$databasename="";
 $link=mysqli_connect($servername,$username,$password,$databasename);
$qry="SELECT * FROM login_user WHERE email='$email' and password = '$password'";
$q="INSERT INTO ``(`email`, `password`) VALUES ('$email','$password')";

$test=mysqli_query($link,$q);
$row  = mysqli_fetch_array($result);
        if(is_array($row)) {
    $_SESSION["email"] = $row['email'];
		$_SESSION["password"] = $row['password'];
        } else {
         $message ="Invalid Username or Password!";
        }
                                                                                                          
    if(isset($_SESSION["cnic"])) {
    header("Location:index.php");
    }




?>