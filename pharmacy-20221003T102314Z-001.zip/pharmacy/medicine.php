<?php
$mname=$_POST['mname'];
$cname=$_POST['cname'];

$servername="localhost";
$username="root";
$password="";
$databasename="";
 $link=mysqli_connect($servername,$username,$password,$databasename);

$q="INSERT INTO ``(`mname`, `cname`) VALUES ('$mname','$cname')";

$test=mysqli_query($link,$q);





?>