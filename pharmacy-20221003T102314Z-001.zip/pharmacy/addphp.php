<?php
$cname=$_POST['cname'];
$mname=$_POST['mname'];
$unit=$_POST['unit'];
$price=$_POST['price'];
$edate=$_POST['edate'];
$servername="localhost";
$username="root";
$password="";
$databasename="";
 $link=mysqli_connect($servername,$username,$password,$databasename);

$q="INSERT INTO ``(`cname`,`mname`,`unit`, `price`,`edate`) VALUES ('$cname','$fname','$unit','$price','$edate')";

$test=mysqli_query($link,$q);





?>