<?php

$cname=$_POST['cname'];

$servername="localhost";
$username="root";
$password="";
$databasename="";
 $link=mysqli_connect($servername,$username,$password,$databasename);

$q="INSERT INTO ``(`cname`) VALUES ('$cname')";

$test=mysqli_query($link,$q);





?>