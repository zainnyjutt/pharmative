<?php
$fname=$_POST['fname'];
$email=$_POST['email'];
$password=$_POST['password'];
$cnic=$_POST['cnic'];
$servername="localhost";
$username="root";
$password="";
$databasename="";
 $link=mysqli_connect($servername,$username,$password,$databasename);

$q="INSERT INTO ``(`fname`,`email`, `password`,`cnic`) VALUES ('$fname','$email','$password','$cnic')";

$test=mysqli_query($link,$q);





?>